# LosslessCodec1

Compressor lossless de WAV PCM 16-bit para CLSS. A versão CLSS 2 preserva os bytes do contentor WAV que não são áudio, permitindo reconstruir o ficheiro WAV original byte a byte. O programa também pode ser chamado a partir do menu de contexto do gestor de ficheiros.

## Requisitos de compilação

- CMake 3.20 ou superior
- Compilador C++17
- Windows: MinGW-w64 ou MSVC
- Linux: GCC ou Clang

## Compilar no Windows

A partir da pasta do projeto, num terminal com CMake e um compilador C++ disponíveis:

    cmake -S . -B build-user
    cmake --build build-user --config Release

Se o compilador MSYS2 falhar por causa de caracteres Unicode no caminho do projeto, usa Strawberry GCC ou MSVC, ou coloca a pasta do projeto num caminho sem caracteres Unicode.

O executável principal fica em build-user\MyLosslessCodec.exe. O CMake também cria `wav_lossless_enc.exe` e `wav_lossless_dec.exe` na mesma pasta. Em Windows, o programa recebe caminhos em UTF-16 e abre ficheiros por caminhos UTF-8 convertidos para o formato nativo. Com MinGW, o CMake liga estaticamente os runtimes do GCC e winpthread para o executável não depender dessas DLLs no computador de quem o usa.

Instala as opções do menu para a tua conta:

    powershell -NoProfile -File .\install_context_menu.ps1 -ExecutablePath .\build-user\MyLosslessCodec.exe

Depois podes clicar com o botão direito num WAV e escolher Comprimir para CLSS, ou num CLSS e escolher Descomprimir para WAV. Em Windows 11, estas opções podem estar em Mostrar mais opções. Para as remover, executa uninstall_context_menu.ps1.

## Compilar no Linux

    cmake -S . -B build-user -DCMAKE_BUILD_TYPE=Release
    cmake --build build-user

O executável principal fica em build-user/MyLosslessCodec. O CMake também cria `wav_lossless_enc` e `wav_lossless_dec` na mesma pasta. Instala as ações de contexto para o utilizador atual com:

    bash ./install_context_menu.sh build-user/MyLosslessCodec

A instalação cria ações para:

- Nautilus e Nemo, no submenu Scripts
- Dolphin, como ações para ficheiros WAV e CLSS
- Thunar, se Python 3 estiver instalado (as ações são integradas na configuração existente)

Para remover as ações, executa:

    bash ./uninstall_context_menu.sh

O suporte ao menu de contexto no Linux depende do gestor de ficheiros; o instalador cobre Nautilus, Nemo, Dolphin e Thunar. Para Dolphin, update-mime-database atualiza a associação local de .clss. Outros gestores podem exigir uma integração própria. Se moveres a pasta depois da instalação, volta a executar o instalador com o novo caminho do executável.

## Uso pela linha de comandos

Os nomes de comando pedidos no exercício são:

    wav_lossless_enc input.wav compressed_file
    wav_lossless_dec compressed_file output.wav

Executa-os a partir da pasta do projeto, por exemplo:

    Windows: .\build-user\wav_lossless_enc.exe input.wav compressed.clss
    Windows: .\build-user\wav_lossless_dec.exe compressed.clss restored.wav
    Linux:   ./build-user/wav_lossless_enc input.wav compressed.clss
    Linux:   ./build-user/wav_lossless_dec compressed.clss restored.wav

Os dois ficheiros devem ser indicados explicitamente nesses comandos. A interface anterior continua disponível; nela o argumento de saída é opcional e, se omitido, o resultado é criado junto do ficheiro de entrada. Se o nome já existir, acrescenta-se um número para evitar substituí-lo.

MyLosslessCodec -c entrada.wav [saida.clss]
MyLosslessCodec -d entrada.clss [saida.wav]
MyLosslessCodec -t original.wav reconstruido.wav

O formato WAV suportado é PCM de 16 bits. Em Windows, escolhe um compilador MinGW-w64/Strawberry ou MSVC que consiga compilar o projeto no caminho onde o descarregaste; algumas distribuições MSYS2 podem falhar quando o caminho da pasta contém caracteres Unicode.

O modo `-t` compara primeiro as amostras e depois todos os bytes dos dois WAVs. Os ficheiros CLSS criados antes da versão 2 não incluem a estrutura original do WAV e não são aceites pelo descodificador atual.

Para reduzir memória temporária, o encoder calcula resíduos e valores ZigZag um de cada vez em cada passagem, em vez de guardar vetores adicionais do tamanho do áudio. O decoder também reconstrói diretamente cada amostra no vetor final. O bitstream comprimido e a estrutura não-PCM do WAV continuam a ser mantidos em memória durante a operação.

O encoder avalia `k` de 0 a 17 (para PCM de 16 bits, valores maiores não reduzem o comprimento Rice) e usa PCM cru quando o payload Rice ocuparia pelo menos tantos bytes como o PCM original. Esta escolha evita expandir o payload de áudio; o cabeçalho CLSS e a estrutura WAV preservada ainda podem fazer com que ficheiros muito curtos ou pouco compressíveis resultem num CLSS maior do que o WAV.
