// Predictor de ordem 1 por canal: codifica diferenças e reconstrói somando a amostra anterior correspondente.
#include "predictor.hpp"

#include <limits>

using namespace std;
// Calcula resíduos de amostras do mesmo canal
bool computeResidualAt(const vector<int16_t>& samples, size_t index, uint16_t channels, int32_t& residual){
    if (channels == 0 || index >= samples.size())
        return false;

    residual = index < channels ? static_cast<int32_t>(samples[index]) : static_cast<int32_t>(samples[index]) - static_cast<int32_t>(samples[index - channels]);
    return true;
}

// Reconstrói uma amostra e rejeita resíduos que não possam representar PCM de 16 bits.
bool reconstructSampleAt(int32_t residual, const vector<int16_t>& reconstructed, size_t index, uint16_t channels, int16_t& sample){
    if (channels == 0 || index >= reconstructed.size())
        return false;

    const int64_t value = index < channels ? residual: static_cast<int64_t>(residual) + static_cast<int64_t>(reconstructed[index - channels]);
    if (value < numeric_limits<int16_t>::min() || value > numeric_limits<int16_t>::max())
        return false;

    sample = static_cast<int16_t>(value);
    return true;
}

// Calcula os resíduos por canal: primeira amostra literal e seguintes como diferença para o frame anterior.
vector<int32_t> computeResiduals(const vector<int16_t>& samples, uint16_t channels){
    if (samples.empty() || channels == 0)
        return {};

    vector<int32_t> residuals(samples.size());
    for (size_t i = 0; i < samples.size(); ++i){
    if (!computeResidualAt(samples, i, channels, residuals[i]))
            return {};
    }
    return residuals;
}

// Reconstrói cada amostra somando o resíduo à amostra anterior do mesmo canal.
vector<int16_t> reconstructSamples(const vector<int32_t>& residuals, uint16_t channels){
    if (residuals.empty() || channels == 0)
        return {};
    vector<int16_t> samples(residuals.size());
    for (size_t i = 0; i < residuals.size(); ++i){
        if (!reconstructSampleAt(residuals[i], samples, i, channels, samples[i]))
            return {};
    }
    return samples;
}
