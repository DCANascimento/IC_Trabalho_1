#include "rice.hpp"

using namespace std;
// Codifica um valor como quociente unario (1...10) seguido do resto em k bits.
// BitWriter concatena os codigos em bytes, sem alinhar cada valor separadamente.
bool riceEncode(uint32_t value, uint8_t k, BitWriter& writer){
    if (k > 31)
        return false;

    const uint32_t divisor = 1u << k;
    const uint32_t quotient = value / divisor;
    const uint32_t remainder = value % divisor;

    for (uint32_t i = 0; i < quotient; ++i)
        writer.writeBit(true);

    writer.writeBit(false); // Terminador do quociente unario.
    writer.writeBits(remainder, k);
    return true;
}

// Le o quociente unario e os k bits do resto pelo BitReader, validando limites.
bool riceDecode(BitReader& reader, uint8_t k, uint32_t& value){
    if (k > 31)
        return false;

    uint32_t quotient = 0;
    while (true){
        bool bit = false;
        if (!reader.readBit(bit))
            return false;
        if (!bit)
            break;
        if (quotient == 0xFFFFFFFFu)
            return false;
        ++quotient;
    }

    uint32_t remainder = 0;
    if (!reader.readBits(remainder, k))
        return false;

    const uint32_t divisor = 1u << k;
    const uint64_t decoded = static_cast<uint64_t>(quotient) * divisor + remainder;
    if (decoded > 0xFFFFFFFFu)
        return false;

    value = static_cast<uint32_t>(decoded);
    return true;
}