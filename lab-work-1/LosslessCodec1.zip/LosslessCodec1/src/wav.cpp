// Le e escreve WAV RIFF PCM de 16 bits, verificando os limites dos chunks.
#include "wav.hpp"
#include "path_utils.hpp"

#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <limits>

using namespace std;
namespace
{
// Le um inteiro de 16 bits no formato little-endian definido pelo RIFF.
bool readU16LE(istream& file, uint16_t& value){
    unsigned char bytes[2];
    if (!file.read(reinterpret_cast<char*>(bytes), sizeof(bytes)))
        return false;
    value = static_cast<uint16_t>(bytes[0])
          | static_cast<uint16_t>(bytes[1] << 8);
    return true;
}

// Le um inteiro de 32 bits no formato little-endian definido pelo RIFF.
bool readU32LE(istream& file, uint32_t& value){
    unsigned char bytes[4];
    if (!file.read(reinterpret_cast<char*>(bytes), sizeof(bytes)))
        return false;
    value = static_cast<uint32_t>(bytes[0])
          | (static_cast<uint32_t>(bytes[1]) << 8)
          | (static_cast<uint32_t>(bytes[2]) << 16)
          | (static_cast<uint32_t>(bytes[3]) << 24);
    return true;
}

// Escreve um inteiro de 16 bits no formato little-endian do WAV.
bool writeU16LE(ostream& file, uint16_t value){
    const unsigned char bytes[2] = {
        static_cast<unsigned char>(value & 0xFFu),
        static_cast<unsigned char>((value >> 8) & 0xFFu)
    };
    return static_cast<bool>(file.write( reinterpret_cast<const char*>(bytes), sizeof(bytes)));
}

// Escreve um inteiro de 32 bits no formato little-endian do WAV.
bool writeU32LE(ostream& file, uint32_t value){
    const unsigned char bytes[4] = {
        static_cast<unsigned char>(value & 0xFFu),
        static_cast<unsigned char>((value >> 8) & 0xFFu),
        static_cast<unsigned char>((value >> 16) & 0xFFu),
        static_cast<unsigned char>((value >> 24) & 0xFFu)
    };
    return static_cast<bool>(file.write( reinterpret_cast<const char*>(bytes), sizeof(bytes)));
}
}

// abre o ficheiro e verifica a assinatura RIFF/WAVE. 
// Depois percorre os chunks até encontrar fmt e data, validando que o áudio é PCM de 16 bits e que os metadados são coerentes.
bool loadWavInfo(const string& filename, WavInfo& info, vector<int16_t>& samples, WavLayout* layout){
    samples.clear();
    info = {};
    if (layout)
        *layout = {};

    ifstream file(filePathFromUtf8(filename), ios::binary);
    if (!file){
        cerr << "Erro: nao foi possivel abrir o ficheiro: " << filename << '\n';
        return false;
    }

    file.seekg(0, ios::end);
    const streamoff physicalSize = file.tellg();
    if (physicalSize < 12){
        cerr << "Erro: ficheiro WAV demasiado pequeno.\n";
        return false;
    }
    file.seekg(0, ios::beg);

    char riff[4];
    uint32_t riffSize = 0;
    char wave[4];
    if (!file.read(riff, sizeof(riff)) || !readU32LE(file, riffSize) || !file.read(wave, sizeof(wave)))
    {
        cerr << "Erro ao ler o cabecalho RIFF/WAVE.\n";
        return false;
    }
    if (string(riff, 4) != "RIFF" || string(wave, 4) != "WAVE")
    {
        cerr << "Erro: o ficheiro nao tem assinatura RIFF/WAVE.\n";
        return false;
    }

    // riffSize conta os bytes a partir do campo WAVE; bytes extra no fim sao ignorados.
    const uint64_t riffEnd = 8ull + riffSize;
    if (riffSize < 4 || riffEnd > static_cast<uint64_t>(physicalSize))
    {
        cerr << "Erro: tamanho RIFF invalido ou ficheiro truncado.\n";
        return false;
    }

    bool foundFmt = false;
    bool foundData = false;
    uint16_t channels = 0;
    uint16_t bitsPerSample = 0;
    uint32_t sampleRate = 0;
    uint32_t dataSize = 0;
    uint64_t dataOffset = 0;
    uint16_t blockAlign = 0;

    // Percorre chunks sem ultrapassar o fim RIFF nem o fim fisico do ficheiro.
    while (true)
    {
        const streamoff headerPosition = file.tellg();
        if (headerPosition < 0)
        {
            cerr << "Erro ao localizar um chunk WAV.\n";
            return false;
        }
        const uint64_t position = static_cast<uint64_t>(headerPosition);
        if (position == riffEnd)
            break;
        if (position > riffEnd || riffEnd - position < 8)
        {
            cerr << "Erro: cabecalho de chunk incompleto dentro do RIFF.\n";
            return false;
        }

        char chunkId[4];
        uint32_t chunkSize = 0;
        if (!file.read(chunkId, sizeof(chunkId)) || !readU32LE(file, chunkSize))
        {
            cerr << "Erro ao ler o cabecalho de um chunk WAV.\n";
            return false;
        }

        const uint64_t payloadStart = position + 8;
        const uint64_t paddedChunkSize =
            static_cast<uint64_t>(chunkSize) + (chunkSize & 1u);
        const uint64_t physicalEnd = static_cast<uint64_t>(physicalSize);
        if (paddedChunkSize > riffEnd - payloadStart
            || payloadStart > physicalEnd
            || paddedChunkSize > physicalEnd - payloadStart)
        {
            cerr << "Erro: chunk WAV ultrapassa os limites declarados.\n";
            return false;
        }

        const bool isFmt = string(chunkId, 4) == "fmt ";
        const bool isData = string(chunkId, 4) == "data";

        if (isFmt && !foundFmt)
        {
            if (chunkSize < 16)
            {
                cerr << "Erro: chunk fmt demasiado pequeno.\n";
                return false;
            }

            uint16_t audioFormat = 0;
            uint32_t byteRate = 0;
            if (!readU16LE(file, audioFormat)
                || !readU16LE(file, channels)
                || !readU32LE(file, sampleRate)
                || !readU32LE(file, byteRate)
                || !readU16LE(file, blockAlign)
                || !readU16LE(file, bitsPerSample))
            {
                cerr << "Erro ao ler os campos do chunk fmt.\n";
                return false;
            }

            if (audioFormat != 1)
            {
                cerr << "Erro: apenas WAV PCM sem compressao e suportado.\n";
                return false;
            }
            if (channels == 0 || sampleRate == 0 || bitsPerSample != 16)
            {
                cerr << "Erro: metadados WAV invalidos ou resolucao nao suportada.\n";
                return false;
            }

            const uint64_t expectedAlign = static_cast<uint64_t>(channels) * 2;
            const uint64_t expectedByteRate =
                static_cast<uint64_t>(sampleRate) * expectedAlign;
            if (expectedAlign > UINT16_MAX || blockAlign != expectedAlign
                || expectedByteRate > UINT32_MAX || byteRate != expectedByteRate)
            {
                cerr << "Erro: byte rate ou block align inconsistente.\n";
                return false;
            }
            foundFmt = true;
        }

        if (isData && !foundData)
        {
            dataSize = chunkSize;
            dataOffset = payloadStart;
            foundData = true;
        }

        const uint64_t nextChunk = payloadStart + paddedChunkSize;
        if (foundFmt && foundData)
            break;
        file.seekg(static_cast<streamoff>(nextChunk), ios::beg);
        if (!file)
        {
            cerr << "Erro ao avancar para o proximo chunk WAV.\n";
            return false;
        }
    }

    if (!foundFmt || !foundData)
    {
        cerr << "Erro: chunk fmt ou data nao encontrado.\n";
        return false;
    }
    if (dataSize % blockAlign != 0)
    {
        cerr << "Erro: os dados nao contem frames completos.\n";
        return false;
    }

    const uint64_t sampleCount64 = dataSize / sizeof(int16_t);
    if (sampleCount64 > samples.max_size())
    {
        cerr << "Erro: WAV demasiado grande para memoria.\n";
        return false;
    }

    samples.resize(static_cast<size_t>(sampleCount64));
    file.seekg(static_cast<streamoff>(dataOffset), ios::beg);
    if (!file)
    {
        cerr << "Erro ao localizar os dados PCM.\n";
        samples.clear();
        return false;
    }

    // Converte blocos little-endian para int16_t sem depender da ordem de bytes da maquina.
    array<unsigned char, 8192> bytes{};
    size_t sampleIndex = 0;
    while (sampleIndex < samples.size())
    {
        const size_t count =
            min(bytes.size() / 2, samples.size() - sampleIndex);
        const streamsize byteCount =
            static_cast<streamsize>(count * 2);
        if (!file.read(reinterpret_cast<char*>(bytes.data()), byteCount))
        {
            cerr << "Erro: dados PCM truncados.\n";
            samples.clear();
            return false;
        }

        for (size_t i = 0; i < count; ++i)
        {
            const uint16_t raw = static_cast<uint16_t>(bytes[2 * i])
                               | static_cast<uint16_t>(bytes[2 * i + 1] << 8);
            const int32_t signedValue = raw < 0x8000u
                ? raw : static_cast<int32_t>(raw) - 0x10000;
            samples[sampleIndex + i] = static_cast<int16_t>(signedValue);
        }
        sampleIndex += count;
    }

    // Mantém os bytes fora do payload PCM para reconstruir depois o contentor
    // original, incluindo chunks desconhecidos e eventuais bytes finais.
    if (layout)
    {
        const uint64_t suffixOffset = dataOffset + dataSize;
        const uint64_t suffixSize =
            static_cast<uint64_t>(physicalSize) - suffixOffset;
        if (dataOffset > layout->prefix.max_size()
            || suffixSize > layout->suffix.max_size()
            || dataOffset > static_cast<uint64_t>(numeric_limits<streamsize>::max())
            || suffixSize > static_cast<uint64_t>(numeric_limits<streamsize>::max()))
        {
            cerr << "Erro: estrutura WAV demasiado grande para memoria.\n";
            samples.clear();
            return false;
        }

        layout->originalFileSize = static_cast<uint64_t>(physicalSize);
        layout->dataOffset = dataOffset;
        layout->prefix.resize(static_cast<size_t>(dataOffset));
        layout->suffix.resize(static_cast<size_t>(suffixSize));

        file.clear();
        file.seekg(0, ios::beg);
        if (!layout->prefix.empty()
            && !file.read(reinterpret_cast<char*>(layout->prefix.data()), static_cast<streamsize>(layout->prefix.size())))
        {
            cerr << "Erro ao guardar a estrutura anterior aos dados WAV.\n";
            samples.clear();
            *layout = {};
            return false;
        }

        file.clear();
        file.seekg(static_cast<streamoff>(suffixOffset), ios::beg);
        if (!layout->suffix.empty()
            && !file.read(reinterpret_cast<char*>(layout->suffix.data()), static_cast<streamsize>(layout->suffix.size())))
        {
            cerr << "Erro ao guardar a estrutura posterior aos dados WAV.\n";
            samples.clear();
            *layout = {};
            return false;
        }
    }

    info.channels = channels;
    info.sampleRate = sampleRate;
    info.bitsPerSample = bitsPerSample;
    info.dataSize = dataSize;
    return true;
}

// Escreve um WAV PCM 16-bit canonico, calculando os tamanhos e codificando little-endian.
bool saveWav(const string& filename, const WavInfo& info, const vector<int16_t>& samples)
{
    if (info.channels == 0 || info.sampleRate == 0 || info.bitsPerSample != 16)
    {
        cerr << "Erro: metadados WAV invalidos ou nao suportados.\n";
        return false;
    }
    if (samples.size() % info.channels != 0)
    {
        cerr << "Erro: numero de amostras nao forma frames completos.\n";
        return false;
    }

    const uint64_t blockAlign64 = static_cast<uint64_t>(info.channels) * 2;
    const uint64_t byteRate64 =
        static_cast<uint64_t>(info.sampleRate) * blockAlign64;
    const uint64_t dataSize64 = static_cast<uint64_t>(samples.size()) * 2;
    if (blockAlign64 > UINT16_MAX || byteRate64 > UINT32_MAX
        || dataSize64 > UINT32_MAX - 36u)
    {
        cerr << "Erro: WAV demasiado grande ou metadados fora do limite.\n";
        return false;
    }

    const uint16_t blockAlign = static_cast<uint16_t>(blockAlign64);
    const uint32_t byteRate = static_cast<uint32_t>(byteRate64);
    const uint32_t dataSize = static_cast<uint32_t>(dataSize64);
    const uint32_t riffSize = 36u + dataSize;

    ofstream file(filePathFromUtf8(filename), ios::binary);
    if (!file)
    {
        cerr << "Erro: nao foi possivel criar " << filename << '\n';
        return false;
    }

    file.write("RIFF", 4);
    writeU32LE(file, riffSize);
    file.write("WAVE", 4);
    file.write("fmt ", 4);
    writeU32LE(file, 16);
    writeU16LE(file, 1);
    writeU16LE(file, info.channels);
    writeU32LE(file, info.sampleRate);
    writeU32LE(file, byteRate);
    writeU16LE(file, blockAlign);
    writeU16LE(file, info.bitsPerSample);
    file.write("data", 4);
    writeU32LE(file, dataSize);

    // Codifica as amostras em blocos para manter baixo o uso extra de memoria.
    array<unsigned char, 8192> bytes{};
    size_t sampleIndex = 0;
    while (sampleIndex < samples.size())
    {
        const size_t count =
            min(bytes.size() / 2, samples.size() - sampleIndex);
        for (size_t i = 0; i < count; ++i)
        {
            const uint16_t raw = static_cast<uint16_t>(samples[sampleIndex + i]);
            bytes[2 * i] = static_cast<unsigned char>(raw & 0xFFu);
            bytes[2 * i + 1] = static_cast<unsigned char>((raw >> 8) & 0xFFu);
        }
        file.write(reinterpret_cast<const char*>(bytes.data()), static_cast<streamsize>(count * 2));
        if (!file)
        {
            cerr << "Erro ao escrever os dados PCM.\n";
            return false;
        }
        sampleIndex += count;
    }

    return static_cast<bool>(file);
}

// escreve o áudio entre os bytes originais do contentor WAV, a partir desta ordem: prefixo, amostras PCM 16-bit e sufixo. Mantem o tamanho original do ficheiro.
bool saveWavPreservingLayout(const string& filename, const WavInfo& info, const vector<int16_t>& samples, const WavLayout& layout)
{
    if (info.channels == 0 || info.sampleRate == 0 || info.bitsPerSample != 16
        || samples.size() % info.channels != 0)
    {
        cerr << "Erro: metadados ou amostras WAV invalidos.\n";
        return false;
    }

    const uint64_t pcmSize = static_cast<uint64_t>(samples.size()) * 2;
    if (pcmSize != info.dataSize || layout.dataOffset != layout.prefix.size()
        || layout.dataOffset > layout.originalFileSize
        || pcmSize > layout.originalFileSize - layout.dataOffset
        || layout.suffix.size() != layout.originalFileSize - layout.dataOffset - pcmSize)
    {
        cerr << "Erro: estrutura original do WAV inconsistente.\n";
        return false;
    }

    ofstream file(filePathFromUtf8(filename), ios::binary);
    if (!file)
    {
        cerr << "Erro: nao foi possivel criar " << filename << '\n';
        return false;
    }

    if (!layout.prefix.empty())
        file.write(reinterpret_cast<const char*>(layout.prefix.data()), static_cast<streamsize>(layout.prefix.size()));

    array<unsigned char, 8192> bytes{};
    size_t sampleIndex = 0;
    while (sampleIndex < samples.size())
    {
        const size_t count =
            min(bytes.size() / 2, samples.size() - sampleIndex);
        for (size_t i = 0; i < count; ++i)
        {
            const uint16_t raw = static_cast<uint16_t>(samples[sampleIndex + i]);
            bytes[2 * i] = static_cast<unsigned char>(raw & 0xFFu);
            bytes[2 * i + 1] = static_cast<unsigned char>((raw >> 8) & 0xFFu);
        }
        file.write(reinterpret_cast<const char*>(bytes.data()), static_cast<streamsize>(count * 2));
        if (!file)
        {
            cerr << "Erro ao escrever as amostras WAV reconstruidas.\n";
            return false;
        }
        sampleIndex += count;
    }

    if (!layout.suffix.empty())
        file.write(reinterpret_cast<const char*>(layout.suffix.data()), static_cast<streamsize>(layout.suffix.size()));

    return static_cast<bool>(file);
}
