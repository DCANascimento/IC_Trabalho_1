#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include "wav.hpp"

enum class PayloadMethod : uint8_t
{
    rawPcm = 0,
    rice = 1
};

// Metadados CLSS v2: identificam o payload Rice/raw e permitem repor o PCM nos bytes WAV originais.
struct CodecHeader{
    uint8_t version;
    uint16_t channels;
    uint32_t sampleRate;
    uint16_t bitsPerSample;
    uint64_t sampleCount;
    uint8_t riceK;
    PayloadMethod payloadMethod;
    uint64_t compressedBitCount;
    uint64_t originalFileSize;
    uint64_t wavDataOffset;
};

// Grava magic CLSS, cabeçalho e bytes comprimidos no caminho indicado.
bool writeCompressedFile(const std::string& filename, const CodecHeader& header, const WavLayout& layout, const std::vector<uint8_t>& data);

// Valida magic CLSS e carrega cabeçalho e bytes restantes; false indica leitura truncada ou ficheiro inválido.
bool readCompressedFile(const std::string& filename, CodecHeader& header, WavLayout& layout, std::vector<uint8_t>& data);
