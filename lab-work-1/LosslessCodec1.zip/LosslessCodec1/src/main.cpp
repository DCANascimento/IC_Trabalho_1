#include <iostream> 
#ifdef _WIN32 // Para evitar conflito com std::min e std::max do C++17, que são usados no código
#ifndef NOMINMAX // Evita que windows.h defina macros min/max que conflitam com std::min/std::max
#define NOMINMAX 
#endif
#include <windows.h>
#endif
#include <vector>
#include <cstdint>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <cstdlib>
#include <string>
#include <fstream>
#include <chrono>
#include <array>

#include "wav.hpp"
#include "predictor.hpp"
#include "zigzag.hpp"
#include "rice.hpp"
#include "bitstream.hpp"
#include "format.hpp"
#include "path_utils.hpp"

using namespace std;

// UTILITÁRIOS
// Calcula a media do valor absoluto das amostras PCM de 16 bits.
double averageAbsolute(const vector<int16_t>& values){
    double sum = 0.0;
    for (auto v : values){
        sum += abs(static_cast<int>(v));
    }
    return values.empty() ? 0.0 : sum / values.size();
}

// Compara os bytes completos de dois ficheiros sem os carregar integralmente para memoria.
bool filesEqualByteForByte(const string& firstFilename, const string& secondFilename){
    ifstream first(filePathFromUtf8(firstFilename), ios::binary);
    ifstream second(filePathFromUtf8(secondFilename), ios::binary);
    if (!first || !second)
        return false;

    first.seekg(0, ios::end);
    second.seekg(0, ios::end);
    const streamoff firstSize = first.tellg();
    const streamoff secondSize = second.tellg();
    if (firstSize < 0 || secondSize < 0 || firstSize != secondSize)
        return false;

    first.seekg(0, ios::beg);
    second.seekg(0, ios::beg);
    array<char, 8192> firstBytes{};
    array<char, 8192> secondBytes{};
    streamoff remaining = firstSize;
    while (remaining > 0){
        const auto count = static_cast<streamsize>(min<streamoff>(remaining, static_cast<streamoff>(firstBytes.size())));
        if (!first.read(firstBytes.data(), count) || !second.read(secondBytes.data(), count)|| !equal(firstBytes.begin(), firstBytes.begin() + count,secondBytes.begin()))
            return false;
        remaining -= count;
    }
    return true;
}

// Calcula a media do valor absoluto dos residuos de 32 bits.
double averageAbsolute(const vector<int32_t>& values){
    double sum = 0.0;
    for (auto v : values){
        sum += abs(v);
    }
    return values.empty() ? 0.0 : sum / values.size();
}

// WAV INFO
// Mostra os metadados do WAV, a duração calculada e algumas informações sobre o vetor de amostras.
void printWavInfo(const WavInfo& info, const vector<int16_t>& samples) {
    const size_t frameCount = samples.size() / info.channels;

    const double duration = static_cast<double>(frameCount)/ info.sampleRate;

    cout << "\n=== WAV INFO ===\n";
    cout << "Channels: " << info.channels << '\n';
    cout << "Sample Rate: "<< info.sampleRate<< " Hz\n";
    cout << "Bits/Sample: " << info.bitsPerSample << '\n';
    cout << "PCM Size: " << info.dataSize<< " bytes\n";
    cout << "Frames: " << frameCount << '\n';
    cout << "Duration      : "<< duration << " s\n";
    cout << "Samples       : "<< samples.size()<< '\n';

    if (!samples.empty()){
        cout << "First Sample  : " << samples.front() << '\n';
        cout << "Last Sample   : " << samples.back() << '\n';
    }
}

// Imprime até count frames, agrupando em cada linha as amostras dos vários canais.
void printFirstFrames(const WavInfo& info, const vector<int16_t>& samples, size_t count = 10){
    const size_t frameCount = samples.size() / info.channels;
    const size_t framesToShow = min(count, frameCount);

    cout << "\n=== FIRST FRAMES ===\n";

    for (size_t frame = 0; frame < framesToShow; ++frame){
        cout << "Frame " << frame << ": ";
        for (size_t ch = 0; ch < info.channels; ++ch){
            const size_t idx = frame * info.channels + ch;
            cout << samples[idx];
            if (ch + 1 < info.channels){
                cout << ", ";
            }
        }
        cout << '\n';
    }
}

// Compressão
// Executa o pipeline WAV → resíduos → ZigZag → Rice e grava o cabeçalho e payload no ficheiro CLSS.
bool compressFile(const string& inputFilename, const string& outputFilename){
    const auto operationStart = chrono::steady_clock::now();
    cout << "\n================================\n" << "          COMPRESSION\n" << "================================\n";

    // Ler WAV
    WavInfo info;
    vector<int16_t> samples;
    WavLayout wavLayout;

    if (!loadWavInfo(inputFilename, info, samples, &wavLayout)){
        cerr << "Erro ao abrir WAV.\n";
        return false;
    }

    printWavInfo(info, samples);

    if (info.channels <= 2){
        printFirstFrames(info, samples);
    }


    // Predictor
    double residualAbsoluteSum = 0.0;
    bool zigzagOk = true;
    for (size_t i = 0; i < samples.size(); ++i){
        int32_t residual = 0;
        if (!computeResidualAt(samples, i, info.channels, residual)){
            cerr << "Erro ao calcular os residuos PCM.\n";
            return false;
        }
        residualAbsoluteSum += abs(residual);
        if (zigzagDecode(zigzagEncode(residual)) != residual)
            zigzagOk = false;
    }

    cout << "\n=== PREDICTOR ===\n";
    cout << "Average |sample|   : " << averageAbsolute(samples) << '\n';
    cout << "Average |residual| : " << (samples.empty() ? 0.0 : residualAbsoluteSum / samples.size()) << '\n';


    // Validar ZigZag
    cout << "\n=== ZIGZAG ===\n";

    if (zigzagOk){
        cout << "Validation OK\n";
    }


    // Escolher melhor k
    cout << "\n=== RICE ANALYSIS ===\n";

    const uint64_t originalBits = static_cast<uint64_t>(info.dataSize) * 8;
    uint8_t bestK = 0;
    uint64_t bestBits = UINT64_MAX;

    // Para PCM16, os resíduos ZigZag não passam de 131070; com k=17 o
    // quociente já é sempre zero, logo valores maiores só aumentariam o código.
    array<uint64_t, 18> riceBitsByK{};
    for (size_t i = 0; i < samples.size(); ++i){
        int32_t residual = 0;
        if (!computeResidualAt(samples, i, info.channels, residual)){
            cerr << "Erro ao calcular os residuos PCM.\n";
            return false;
        }
        const uint32_t value = zigzagEncode(residual);
        for (uint8_t k = 0; k <= 17; ++k){
            const uint32_t quotient = value / (1u << k);
            riceBitsByK[k] += quotient + 1 + k;
        }
    }

    for (uint8_t k = 0; k <= 17;++k){
        const uint64_t totalBits = riceBitsByK[k];
        const double ratio = totalBits == 0 ? 0.0: static_cast<double>(originalBits) / totalBits;
        cout << "k = " << static_cast<int>(k) << " | bits = " << totalBits << " | ratio = " << ratio << '\n';

        if (totalBits < bestBits){
            bestBits = totalBits;
            bestK = k;
        }
    }

    cout << "\n=== BEST RICE PARAMETER ===\n";
    cout << "Best k    : " << static_cast<int>(bestK) << '\n';
    cout << "Best bits : " << bestBits << '\n';

    if (bestBits > 0)
        cout << "Rice candidate ratio: " << static_cast<double>(originalBits) / bestBits << '\n';

    // Bitstream
    BitWriter writer;
    vector<uint8_t> rawPayload;
    const uint64_t riceByteCount = bestBits / 8 + (bestBits % 8 != 0 ? 1 : 0);
    PayloadMethod payloadMethod = PayloadMethod::rice;
    uint64_t payloadBitCount = bestBits;
    const vector<uint8_t>* payload = nullptr;

    // Se Rice não reduzir sequer os bytes do PCM, guardar o PCM cru evita expandir áudio ruidoso.
    if (riceByteCount < info.dataSize)
    {
        for (size_t i = 0; i < samples.size(); ++i)
        {
            int32_t residual = 0;
            if (!computeResidualAt(samples, i, info.channels, residual)){
                cerr << "Erro ao calcular os residuos PCM.\n";
                return false;
            }
            if (!riceEncode(zigzagEncode(residual), bestK, writer)){
                cerr << "Erro: parametro Rice invalido.\n";
                return false;
            }
        }
        writer.flush();
        payload = &writer.getData();
    } else 
    {
        payloadMethod = PayloadMethod::rawPcm;
        payloadBitCount = originalBits;
        rawPayload.reserve(info.dataSize);
        for (int16_t sample : samples)
        {
            const uint16_t raw = static_cast<uint16_t>(sample);
            rawPayload.push_back(static_cast<uint8_t>(raw & 0xFFu));
            rawPayload.push_back(static_cast<uint8_t>((raw >> 8) & 0xFFu));
        }
        payload = &rawPayload;
    }

    cout << "\n=== BITSTREAM ===\n";
    cout << "Encoded bits  : " << payloadBitCount << '\n';
    cout << "Encoded bytes : " << payload->size() << '\n';
    cout << "Payload method: " << (payloadMethod == PayloadMethod::rice ? "Rice" : "raw PCM") << '\n';
    cout << "Payload ratio : " << (payloadBitCount == 0 ? 0.0 : static_cast<double>(originalBits) / payloadBitCount) << '\n';

    // Header
    CodecHeader header{};
    header.version = 2;
    header.channels = info.channels;
    header.sampleRate = info.sampleRate;
    header.bitsPerSample = info.bitsPerSample;
    header.sampleCount = samples.size();
    header.riceK = bestK;
    header.payloadMethod = payloadMethod;
    header.compressedBitCount = payloadBitCount;
    header.originalFileSize = wavLayout.originalFileSize;
    header.wavDataOffset = wavLayout.dataOffset;

    // Guardar CLSS
    if (!writeCompressedFile(outputFilename, header, wavLayout, *payload)){
        cerr << "Erro ao guardar ficheiro comprimido.\n";
        return false;
    }

    const double elapsedSeconds = chrono::duration<double>(chrono::steady_clock::now() - operationStart).count();
    const double compressionSpeedMBps = elapsedSeconds > 0.0 ? (static_cast<double>(info.dataSize) / 1'000'000.0) / elapsedSeconds: 0.0;

    cout << "\nFicheiro comprimido criado: " << outputFilename << '\n';
    cout << "Tempo de compressao : " << elapsedSeconds << " s\n";
    cout << "Velocidade          : " << compressionSpeedMBps << " MB/s de audio PCM\n";


    // Informação do resultado
    ifstream compressedFile(filePathFromUtf8(outputFilename), ios::binary);

    if (compressedFile){
        compressedFile.seekg(0, ios::end);
        const auto compressedSize = compressedFile.tellg();

        cout << "Tamanho original : " << info.dataSize << " bytes\n";
        cout << "Tamanho CLSS     : " << compressedSize << " bytes\n";
    }
    return true;
}

// descompressão
// Lê um CLSS, valida os metadados, descodifica Rice/ZigZag e reconstrói o WAV de saída.
bool decompressFile(const string& inputFilename, const string& outputFilename){
    const auto operationStart = chrono::steady_clock::now();

    cout << "\n================================\n" << "         DECOMPRESSION\n" << "================================\n";

    // Ler ficheiro CLSS
    CodecHeader header;
    WavLayout wavLayout;
    vector<uint8_t> compressedData; // Payload Rice ou PCM cru

    if (!readCompressedFile(inputFilename, header, wavLayout, compressedData)){
        cerr << "Erro ao ler ficheiro CLSS.\n";
        return false;
    }

    // Validar header
    if (header.version != 2){
        cerr << "Erro: versao CLSS nao suportada: " << static_cast<int>( header.version ) << '\n';
        return false;
    }

    if (header.channels == 0){
        cerr << "Erro: numero de canais invalido.\n";
        return false;
    }

    if (header.sampleRate == 0){
        cerr << "Erro: sample rate invalido.\n";
        return false;
    }

    if (header.bitsPerSample != 16){
        cerr << "Erro: apenas PCM 16-bit e suportado.\n";
        return false;
    }

    cout << "\n=== CLSS HEADER ===\n";
    cout << "Version          : " << static_cast<int>( header.version ) << '\n';
    cout << "Channels         : " << header.channels << '\n';
    cout << "Sample Rate      : " << header.sampleRate << '\n';
    cout << "Bits/Sample      : " << header.bitsPerSample << '\n';
    cout << "Sample Count     : " << header.sampleCount << '\n';
    cout << "Rice k           : " << static_cast<int>( header.riceK ) << '\n';
    cout << "Payload method   : " << (header.payloadMethod == PayloadMethod::rice ? "Rice" : "raw PCM") << '\n';
    cout << "Compressed Bits  : " << header.compressedBitCount << '\n';
    cout << "Compressed Bytes : " << compressedData.size() << '\n';

    // Verificar se temos bytes suficientes
    const uint64_t availableBits =
        static_cast<uint64_t>(compressedData.size()) * 8;

    if (header.compressedBitCount >
        availableBits)
    {
        cerr << "Erro: bitstream incompleto.\n";

        return false;
    }

    // BitReader
    BitReader reader(compressedData);

    // Rice Decode
    if (header.sampleCount > vector<int16_t>().max_size()|| header.sampleCount % header.channels != 0){
        cerr << "Erro: numero de amostras invalido para os canais.\n";
        return false;
    }

    vector<int16_t> decodedSamples(static_cast<size_t>(header.sampleCount));

    if (header.payloadMethod == PayloadMethod::rice){
        for (uint64_t i = 0; i < header.sampleCount; ++i){
            uint32_t value = 0;
            if (!riceDecode(reader, header.riceK, value)){
                cerr << "Erro durante a descodificacao Rice.\n";
                return false;
            }
            const int32_t residual = zigzagDecode(value);
            const size_t index = static_cast<size_t>(i);
            if (!reconstructSampleAt(residual, decodedSamples, index, header.channels, decodedSamples[index])){
                cerr << "Erro: valor descodificado fora do intervalo PCM 16-bit.\n";
                return false;
            }
        }
        if (reader.bitsRead() != header.compressedBitCount){
            cerr << "Erro: o numero de bits Rice nao corresponde ao cabecalho.\n";
            return false;
        }
    } else {
        for (size_t i = 0; i < decodedSamples.size(); ++i){
            const size_t byteIndex = i * 2;
            const uint16_t raw = static_cast<uint16_t>(compressedData[byteIndex])| static_cast<uint16_t>(static_cast<uint16_t>(compressedData[byteIndex + 1]) << 8);
            const int32_t signedValue = raw < 0x8000u ? raw : static_cast<int32_t>(raw) - 0x10000;
            decodedSamples[i] = static_cast<int16_t>(signedValue);
        }
    }

    // Criar WavInfo
    WavInfo info{};
    info.channels = header.channels;
    info.sampleRate = header.sampleRate;
    info.bitsPerSample = header.bitsPerSample;
    info.dataSize = static_cast<uint32_t>(decodedSamples.size() * sizeof(int16_t));

    // Guardar WAV
    if (!saveWavPreservingLayout(outputFilename, info, decodedSamples, wavLayout)){
        cerr << "Erro ao criar WAV reconstruido.\n";
        return false;
    }

    const double elapsedSeconds = chrono::duration<double>(chrono::steady_clock::now() - operationStart).count();
    const uint64_t reconstructedPcmBytes = static_cast<uint64_t>(decodedSamples.size()) * sizeof(int16_t);
    const double decompressionSpeedMBps = elapsedSeconds > 0.0 ? (static_cast<double>(reconstructedPcmBytes) / 1'000'000.0)/ elapsedSeconds: 0.0;

    cout << "\nWAV reconstruido criado: " << outputFilename << '\n';
    cout << "Tempo de descompressao : " << elapsedSeconds << " s\n";
    cout << "Velocidade            : " << decompressionSpeedMBps << " MB/s de audio PCM\n";
    cout << "\n=== DECOMPRESSION SUCCESS ===\n";
    cout << "Samples reconstruidos: " << decodedSamples.size() << '\n';

    return true;
}

// COMPARAR DOIS WAVS
// Compara metadados, amostras e todos os bytes dos WAVs para confirmar igualdade exata.
bool compareWavFiles(const string& firstFilename, const string& secondFilename){
    WavInfo firstInfo;
    WavInfo secondInfo;

    vector<int16_t> firstSamples;
    vector<int16_t> secondSamples;

    if (!loadWavInfo(firstFilename, firstInfo, firstSamples)){
        return false;
    }

    if (!loadWavInfo(secondFilename, secondInfo, secondSamples)){
        return false;
    }

    cout << "\n=== LOSSLESS COMPARISON ===\n";

    // Comparar canais
    if (firstInfo.channels != secondInfo.channels){
        cout << "FAIL: numero de canais diferente.\n";
        return false;
    }

    // Comparar sample rate
    if (firstInfo.sampleRate != secondInfo.sampleRate){
        cout << "FAIL: sample rate diferente.\n";
        return false;
    }

    // Comparar bits por sample
    if (firstInfo.bitsPerSample != secondInfo.bitsPerSample){
        cout << "FAIL: bits por sample diferente.\n";
        return false;
    }

    // Comparar número de samples
    if (firstSamples.size() != secondSamples.size()){
        cout << "FAIL: numero de samples diferente.\n";
        cout << "Original: " << firstSamples.size() << '\n';
        cout << "Restored: " << secondSamples.size() << '\n';
        return false;
    }

    // Comparar cada sample
    for (size_t i = 0;
         i < firstSamples.size();
         ++i)
    {
        if (firstSamples[i] != secondSamples[i]){
            cout << "FAIL: samples diferentes.\n";
            cout << "Primeiro erro no indice: " << i << '\n';
            cout << "Original    : " << firstSamples[i] << '\n';
            cout << "Reconstruido : " << secondSamples[i] << '\n';

            return false;
        }
    }

    if (!filesEqualByteForByte(firstFilename, secondFilename)){
        cout << "FAIL: as amostras coincidem, mas os bytes dos WAVs diferem.\n";
        return false;
    }

    // Tudo igual
    cout << "SUCCESS: os WAVs sao identicos byte a byte.\n";
    return true;
}

// USAGE
// Gera o destino preservando os bytes UTF-8 do caminho de entrada.

string chooseDefaultOutputFilename(const string& inputFilename, const string& extension){
    const size_t separator = inputFilename.find_last_of("/\\");
    const string parent = separator == string::npos ? string{} : inputFilename.substr(0, separator + 1);
    const string filename = separator == string::npos ? inputFilename : inputFilename.substr(separator + 1);
    const size_t dot = filename.find_last_of('.');
    const string stem = dot == string::npos || dot == 0 ? filename : filename.substr(0, dot);

    for (uint32_t suffix = 1; suffix <= 100000; ++suffix){
        const string candidate = parent + stem + (suffix == 1 ? string{} : " (" + to_string(suffix) + ")") + extension;
        ifstream existing(filePathFromUtf8(candidate), ios::binary);
        if (!existing)
            return candidate;
    }
    return {};
}

// Extrai o nome do executável para reconhecer as entradas encoder/decoder pedidas no exercício.
string executableStem(const string& executablePath){
    const size_t separator = executablePath.find_last_of("/\\");
    const string filename = separator == string::npos ? executablePath : executablePath.substr(separator + 1);
    const size_t dot = filename.find_last_of('.');
    return dot == string::npos ? filename : filename.substr(0, dot);
}

// Apresenta os modos de chamada e a forma opcional de indicar o ficheiro de saida.
void printUsage(const char* programName){
    cout << "\nUso:\n\n"  << "  Compressao:\n" << "    " << programName << " -c input.wav [output.clss]\n\n"  << "  Descompressao:\n" << "    " << programName << " -d input.clss [output.wav]\n\n"  << "  Teste lossless:\n" << "    " << programName << " -t original.wav restored.wav\n\n"  << "  Formato do exercicio (executaveis wav_lossless_enc/dec):\n" << "    wav_lossless_enc input.wav compressed_file\n" << "    wav_lossless_dec compressed_file output.wav\n\n";
}

// MAIN
// Interpreta os argumentos; sem argumentos pede interativamente o WAV e o destino da compressão.
#ifdef _WIN32
// Converte um argumento UTF-16 do Windows para UTF-8, que e o formato interno usado pelo codec para todos os caminhos.
string wideToUtf8(const wstring& value){
    if (value.empty())
        return {};

    const int sourceLength = static_cast<int>(value.size());
    const int outputLength = WideCharToMultiByte(CP_UTF8, 0, value.data(), sourceLength, nullptr, 0, nullptr, nullptr);

    if (outputLength <= 0)
        return {};

    string output(static_cast<size_t>(outputLength), '\0');
    if (WideCharToMultiByte(CP_UTF8, 0, value.data(), sourceLength, output.data(), outputLength, nullptr, nullptr) <= 0){
        return {};
    }
    return output;
}
#endif

// Escolhe a operação pedida: compressao, descompressao e comparacao.
// Os argumentos de ficheiro chegam aqui sempre em UTF-8.
int runApplication(const vector<string>& args){
    const int argc = static_cast<int>(args.size());
    const string programStem = executableStem(args[0]);

    // Os nomes de executável do enunciado selecionam diretamente a operação.
    if (programStem == "wav_lossless_enc"){
        if (argc != 3){ // argc é o número de argumentos
            printUsage(args[0].c_str());
            return EXIT_FAILURE;
        }
        return compressFile(args[1], args[2]) ? EXIT_SUCCESS : EXIT_FAILURE;
    }
    if (programStem == "wav_lossless_dec"){
        if (argc != 3){
            printUsage(args[0].c_str());
            return EXIT_FAILURE;
        }
        return decompressFile(args[1], args[2]) ? EXIT_SUCCESS : EXIT_FAILURE;
    }

    // Sem argumentos, pedir interativamente o WAV a comprimir.
    if (argc == 1){
        string inputFilename;
        string outputFilename;
        cout << "Ficheiro WAV a comprimir: ";
#ifdef _WIN32
        wstring wideInput;
        getline(wcin, wideInput);
        inputFilename = wideToUtf8(wideInput);
#else
        getline(cin, inputFilename);
#endif
        if (inputFilename.empty()){
            cerr << "Erro: indique o caminho de um ficheiro WAV.\n";
            return EXIT_FAILURE;
        }

        outputFilename = chooseDefaultOutputFilename(inputFilename, ".clss");
        if (outputFilename.empty()){
            cerr << "Erro: nao foi possivel escolher um destino de saida.\n";
            return EXIT_FAILURE;
        }

        cout << "Ficheiro de saida [" << outputFilename << "]: ";
        string chosenOutput;
#ifdef _WIN32
        wstring wideOutput;
        getline(wcin, wideOutput);
        chosenOutput = wideToUtf8(wideOutput);
#else
        getline(cin, chosenOutput);
#endif
        if (!chosenOutput.empty())
            outputFilename = chosenOutput;

        return compressFile(inputFilename, outputFilename)? EXIT_SUCCESS: EXIT_FAILURE;
    }

    // O menu de contexto envia apenas modo e caminho; o codec inventa a saida:
    // A função gera automaticamente um nome: .clss para compressão ou .wav para descompressão
    if (argc == 3 && (args[1] == "-c" || args[1] == "-d")){
        const string& mode = args[1];
        const string& inputFilename = args[2];
        const string extension = mode == "-c" ? ".clss" : ".wav";
        const string outputFilename =
            chooseDefaultOutputFilename(inputFilename, extension);

        if (outputFilename.empty()){
            cerr << "Erro: nao foi possivel escolher um destino de saida.\n";
            return EXIT_FAILURE;
        }

        cout << "Ficheiro de saida: " << outputFilename << '\n';
        const bool success = mode == "-c" ? compressFile(inputFilename, outputFilename): decompressFile(inputFilename, outputFilename);
        return success ? EXIT_SUCCESS : EXIT_FAILURE;
    }

    if (argc != 4){
        printUsage(args[0].c_str());
        return EXIT_FAILURE;
    }

    const string& mode = args[1];
    const string& inputFilename = args[2];
    const string& outputFilename = args[3];

    if (mode == "-c"){
        if (compressFile(inputFilename, outputFilename)){
            cout << "\nCompression completed successfully.\n";
            return EXIT_SUCCESS;
        }
        return EXIT_FAILURE;
    }

    if (mode == "-d"){
        if (decompressFile(inputFilename, outputFilename)){
            cout << "\nDecompression completed successfully.\n";
            return EXIT_SUCCESS;
        }
        return EXIT_FAILURE;
    }

    if (mode == "-t"){
        return compareWavFiles(inputFilename, outputFilename)
            ? EXIT_SUCCESS
            : EXIT_FAILURE;
    }

    cerr << "Erro: modo desconhecido: " << mode << '\n';
    printUsage(args[0].c_str());
    return EXIT_FAILURE;
}

#ifdef _WIN32
// O Windows fornece argv em UTF-16, incluindo caminhos com qualquer idioma.
int wmain(int argc, wchar_t* argv[]){
    vector<string> args;
    args.reserve(static_cast<size_t>(argc));
    for (int i = 0; i < argc; ++i)
        args.push_back(wideToUtf8(argv[i]));
    return runApplication(args);
}
#else
// Em Linux, argv ja usa os bytes nativos do caminho; estes sao UTF-8 na maioria
// dos ambientes desktop.
int main(int argc, char* argv[]){
    vector<string> args;
    args.reserve(static_cast<size_t>(argc));
    for (int i = 0; i < argc; ++i)
        args.emplace_back(argv[i]);
    return runApplication(args);
}
#endif
