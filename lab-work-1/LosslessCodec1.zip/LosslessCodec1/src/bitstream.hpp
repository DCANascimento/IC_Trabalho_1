#pragma once

#include <cstdint>
#include <vector>
#include <string>

// BIT WRITER
// Empacota bits do mais significativo para o menos significativo em bytes; flush completa o último byte com zeros.
class BitWriter{
private:
    std::vector<uint8_t> data;

    uint8_t currentByte = 0;
    uint8_t bitCount = 0;

public:
    // Adiciona um bit ao fluxo, preenchendo os bytes da esquerda para a direita.
    void writeBit(bool bit);
    // Escreve os count bits menos significativos de value, do mais significativo para o menos.
    void writeBits(uint32_t value, uint8_t count);
    // Fecha o byte parcial com zeros e deixa os bytes prontos para leitura ou gravação.
    void flush();
    // Dá acesso somente de leitura aos bytes produzidos pelo BitWriter.
    const std::vector<uint8_t>& getData() const;
    // Grava os bytes do writer no ficheiro indicado e comunica falha de abertura/escrita.
    bool saveToFile(const std::string& filename) const;
    // Devolve o tamanho dos bytes já guardados em bits, incluindo padding do último byte.
    std::size_t bitSize() const;
};

// BIT READER
// Lê a sequência empacotada por BitWriter na mesma ordem de bits e informa falhas ao atingir o fim.
class BitReader{
private:
    const std::vector<uint8_t>& data;
    std::size_t byteIndex = 0;
    uint8_t bitIndex = 0;

public:
    // Associa o leitor ao vetor de bytes que será percorrido bit a bit.
    explicit BitReader(const std::vector<uint8_t>& data);
    // Lê o próximo bit MSB-first; false indica que o vetor terminou.
    bool readBit(bool& bit);
    // Lê vários bits consecutivos para um inteiro; false indica dados insuficientes.
    bool readBits(uint32_t& value, uint8_t count);
    // Indica se o leitor já consumiu todos os bytes disponíveis.
    bool end() const;
    // Devolve quantos bits úteis foram consumidos, sem contar o padding final do byte.
    uint64_t bitsRead() const;
};
