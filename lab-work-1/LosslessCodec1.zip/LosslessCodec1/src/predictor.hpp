#pragma once

#include <vector>
#include <cstdint>
#include <cstddef>

// Calcula um resíduo individual sem criar um vetor temporário; devolve false se o índice/canal for inválido.
bool computeResidualAt(const std::vector<int16_t>& samples, std::size_t index, uint16_t channels, int32_t& residual);

// Calcula a diferença para a amostra anterior do mesmo canal; as primeiras amostras de cada canal são copiadas sem previsão.
std::vector<int32_t> computeResiduals(const std::vector<int16_t>& samples, uint16_t channels);

// Reverte computeResiduals, somando cada resíduo à amostra anterior do mesmo canal.
std::vector<int16_t> reconstructSamples(const std::vector<int32_t>& residuals, uint16_t channels);

// Reconstrói uma amostra usando o resíduo atual e a amostra anterior já reconstruída do mesmo canal.
bool reconstructSampleAt(int32_t residual, const std::vector<int16_t>& reconstructed, std::size_t index, uint16_t channels, int16_t& sample);
