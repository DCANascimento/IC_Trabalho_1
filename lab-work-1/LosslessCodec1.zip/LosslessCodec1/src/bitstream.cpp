// Empacota e desempacota bits em ordem MSB-first, isto é, do bit mais significativo para o menos significativo.
#include "bitstream.hpp"
#include "path_utils.hpp"

#include <fstream>

using namespace std;

// BIT WRITER
// Acrescenta um bit ao byte corrente, começando pelo bit mais significativo, e guarda bytes completos.
void BitWriter::writeBit(bool bit)
{
    if (bit){
        currentByte |= static_cast<uint8_t>(1u << (7 - bitCount));
    }
    ++bitCount;

    if (bitCount == 8){
        data.push_back(currentByte);
        currentByte = 0;
        bitCount = 0;
    }
}

// Escreve count bits de value do mais significativo para o menos significativo.
void BitWriter::writeBits(uint32_t value, uint8_t count){
    for (int i = count - 1; i >= 0; --i){
        bool bit =((value >> i) & 1u) != 0;
        writeBit(bit);
    }
}

// Guarda o byte parcial, preenchendo com zeros os bits finais que não pertencem ao payload.
void BitWriter::flush(){
    if (bitCount > 0){
        data.push_back(currentByte);
        currentByte = 0;
        bitCount = 0;
    }
}

// Devolve por referência os bytes já empacotados pelo escritor.
const vector<uint8_t>& BitWriter::getData() const{
    return data;
}

// Devolve a capacidade em bits dos bytes guardados, incluindo qualquer padding do último byte.
size_t BitWriter::bitSize() const{
    return data.size() * 8;
}

// Grava os bytes empacotados num ficheiro binário e indica se a escrita terminou corretamente.
bool BitWriter::saveToFile(const string& filename) const{
    ofstream file(filePathFromUtf8(filename), ios::binary);

    if (!file)
        return false;

    file.write(reinterpret_cast<const char*>(data.data()), static_cast<streamsize>(data.size()));
    return static_cast<bool>(file);
}

// BIT READER
// Inicializa o leitor com referência aos bytes que serão consumidos bit a bit.
BitReader::BitReader(const vector<uint8_t>& data) : data(data){}

// Lê o próximo bit em ordem MSB-first; devolve false quando todos os bytes foram consumidos.
bool BitReader::readBit(bool& bit){
    // Já não existem mais bytes.
    if (byteIndex >= data.size())
        return false;

    // Ler o bit mais significativo primeiro.
    bit = ((data[byteIndex] >> (7 - bitIndex)) & 1u)
        != 0;
    ++bitIndex;

    // Passámos para o byte seguinte.
    if (bitIndex == 8){
        bitIndex = 0;
        ++byteIndex;
    }
    return true;
}

// Lê count bits e junta-os em value, devolvendo false se o fim do vetor chegar antes.
bool BitReader::readBits(uint32_t& value, uint8_t count){
    value = 0;
    for (uint8_t i = 0; i < count; ++i){
        bool bit;

        if (!readBit(bit))
            return false;

        value <<= 1;

        if (bit)
            value |= 1u;
    }
    return true;
}

// Informa se já não existem bytes por ler no BitReader.
bool BitReader::end() const{
    return byteIndex >= data.size();
}

// Devolve a posição em bits para permitir validar a fronteira útil do payload Rice.
uint64_t BitReader::bitsRead() const{
    return static_cast<uint64_t>(byteIndex) * 8 + bitIndex;
}
